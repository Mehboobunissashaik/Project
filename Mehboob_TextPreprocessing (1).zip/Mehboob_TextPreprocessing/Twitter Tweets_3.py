#!/usr/bin/env python
# coding: utf-8

# In[20]:


import pandas as pd
import numpy as np
import re
import nltk
import seaborn as sns
from scipy import stats
import matplotlib.pyplot as plt
import random
import pprint
from nltk import word_tokenize
from nltk.corpus import stopwords
from nltk.stem.porter import PorterStemmer
from nltk.tokenize.toktok import ToktokTokenizer
import spacy
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer, WordNetLemmatizer


# # Data loading

# In[21]:


# Read the CSV file located at the specified path.
df = pd.read_csv(r'C:\Users\mehbosha\Downloads\Tweets Data\training.1600000.processed.noemoticon.csv', encoding='latin1')


# In[22]:


df


# In[23]:


# Description of the DataFrame
df.describe()


# In[24]:


df.info()


# # Missing Values

# In[25]:


# Calculate the sum of null values in each column of the DataFrame.
print(df.isnull().sum())
print('\n\033[1mInference:\033[0m The dataset doesn\'t have any null elements')


# # Duplicates

# In[26]:


# Load the dataset into a DataFrame
df = pd.read_csv(r'C:\Users\mehbosha\Downloads\Tweets Data\training.1600000.processed.noemoticon.csv', encoding='latin1')

# Identify duplicate entries based on all columns
duplicate_rows = df[df.duplicated()]

# Remove duplicate entries
cleaned_df = df.drop_duplicates()

# Identify duplicate entries based on all columns
duplicate_rows = df[df.duplicated()]

# Remove duplicate entries
cleaned_df = df.drop_duplicates()


# In[9]:


df


# # Numeric Values

# In[35]:


# Read the CSV file into a DataFrame
df = pd.read_csv(r'C:\Users\mehbosha\Downloads\Tweets Data\training.1600000.processed.noemoticon.csv', encoding='latin1')
# Define a function to replace numerical values with placeholders
def replace_numerics(text, placeholder='NUMERIC_VALUE'):
    return re.sub(r'\b\d+\b', placeholder, str(text))
# Apply the replace_numerics function to all columns of the DataFrame
df.columns = df.columns.map(replace_numerics)
# Apply the replace_numerics function to all cells in the DataFrame
df = df.applymap(replace_numerics)
# Save the modified DataFrame to a new CSV file
df.to_csv('twitter_modified_file.csv', index=False)
print(df)


# # Text Cleaning

# In[36]:


# Define a function to strip HTML tags from text
def strip_html(text):
    # Create a BeautifulSoup object to parse the HTML
    soup = BeautifulSoup(text, "html.parser")
    # Extract the text content from the HTML and return it
    return soup.get_text()

# Define a function to apply multiple text cleaning operations
def apply_map(text):
    # Check if the input is a string
    if isinstance(text, str):
        # Remove special characters enclosed in '<>' brackets
        text = re.sub(r'<!#$%^&.*@?>', '', text)
        # Remove any characters that are not letters, numbers, or whitespace
        text = re.sub(r'[^a-zA-Z0-9\s]', '', text)
        # Replace any non-word characters (excluding whitespace) with a space and remove leading/trailing whitespace
        text = re.sub(r'[^\w\s]', ' ', text).strip()
        #Remove any links
        text = re.sub(r'http\S+', '', text)
    return text

# Read the CSV file containing modified data into a DataFrame
df = pd.read_csv(r'twitter_modified_file.csv', encoding='latin1')
# Apply the apply_map function to clean text in all cells of the DataFrame
df = df.applymap(apply_map)
# Apply the apply_map function to clean text in all columns of the DataFrame
df.columns = df.columns.map(apply_map)
# Save the cleaned DataFrame to a new CSV file
df.to_csv('twitter_cleaned_file.csv', index=False)

# Print the cleaned text
print(df)


# # Lowercasing

# In[37]:


df = pd.read_csv(r'twitter_cleaned_file.csv', encoding='latin1')

# Convert all text in all columns to lowercase
df = df.applymap(lambda x: x.lower() if isinstance(x, str) else x)
df.to_csv('twitter_lowercased_file.csv', index=False)
# Print the DataFrame to verify the conversion
print(df)


# # Tokenization

# In[38]:


df = pd.read_csv(r'twitter_lowercased_file.csv', encoding='latin1')

# Tokenize text in all columns
for column in df.columns: 
    # Check if the column contains text data (assumed)
    if df[column].dtype == 'object':
        # Tokenize the text data using NLTK tokenizer
        df[column + '_Tokenized'] = df[column].apply(lambda x: word_tokenize(str(x)) if isinstance(x, str) else [])
# Print the DataFrame with tokenized text
df.to_csv('twitter_tokenized_file.csv', index=False)
print(df)


# # Stopwords Removal

# In[39]:


# Define your stop words list (optional)
# You can customize the stopwords list by adding or removing words
stop_words = set(stopwords.words('english'))

# Load the CSV file
df = pd.read_csv(r'twitter_tokenized_file.csv', encoding='latin1')

# Define a function to remove stopwords from text
def remove_stopwords(text):
  # Lowercase the text (optional)
  text = text.lower()
  # Split the text into words
  words = text.split()
  # Filter out stopwords
  filtered_words = [word for word in words if word not in stop_words]
  # Join the filtered words back into a string
  return " ".join(filtered_words)
# Apply stopword removal to each column
for col in df.columns:
  # Check if the column contains text data (avoid removing stopwords from numerical columns)
  if pd.api.types.is_string_dtype(df[col]):
    df[col] = df[col].apply(remove_stopwords)

# Print the DataFrame with stopwords removed
df.to_csv('twitter_stopwords_file.csv', index=False)
print(df)


# # Stemming or Lemmatization

# In[40]:


# Load the CSV file
df = pd.read_csv(r'twitter_stopwords_file.csv', encoding='latin1')

# Initialize Stemmer and Lemmatizer
stemmer = PorterStemmer()
lemmatizer = WordNetLemmatizer()

# Function to apply stemming
def apply_stemming(text):
    words = word_tokenize(str(text))
    stemmed_words = [stemmer.stem(word) for word in words]
    return ' '.join(stemmed_words)

# Function to apply lemmatization
def apply_lemmatization(text):
    words = word_tokenize(str(text))
    lemmatized_words = [lemmatizer.lemmatize(word) for word in words]
    return ' '.join(lemmatized_words)

# Apply stemming to all columns
stemmed_df = df.applymap(apply_stemming)

# Apply lemmatization to all columns
lemmatized_df = df.applymap(apply_lemmatization)

# Save the results to new CSV files
stemmed_df.to_csv('twitter_stemmed_output.csv', index=False)
lemmatized_df.to_csv('twitter_lemmatized_output.csv', index=False)


# In[41]:


df


# In[ ]:




