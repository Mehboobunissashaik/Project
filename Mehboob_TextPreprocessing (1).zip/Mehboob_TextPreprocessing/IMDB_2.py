#!/usr/bin/env python
# coding: utf-8

# # IMDB Sentiment Analysis

# In[114]:


pip install pandas


# In[11]:


pip install beautifulsoup4


# In[115]:


pip install numpy


# In[1]:


import pandas as pd
import numpy as np
import re
import nltk
import seaborn as sns
from scipy import stats
import matplotlib.pyplot as plt
import random
import pprint
from nltk import word_tokenize
from nltk.corpus import stopwords
from nltk.stem.porter import PorterStemmer
from nltk.tokenize.toktok import ToktokTokenizer
import spacy
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer, WordNetLemmatizer
from bs4 import BeautifulSoup


# # Data Loading

# In[2]:


# Read the CSV file located at the specified path.
df = pd.read_csv(r'C:\Users\mehbosha\Downloads\IMDB Dataset\IMDB Dataset.csv', encoding='latin1')


# In[3]:


df


# In[4]:


df.describe()


# In[5]:


# Information about the DataFrame
df.info()


# # Handling Missing Data

# In[6]:


# Calculate the sum of null values in each column of the DataFrame.
print(df.isnull().sum())
print('\n\033[1mInference:\033[0m The dataset doesn\'t have any null elements')


# In[8]:


# Print the shape of the DataFrame 'df' with bold text formatting.
print('\033[1m' + 'df.shape:' + '\033[0m', df.shape)
# Print the column names of the DataFrame 'df' with bold text formatting.
print('\033[1m' + 'df.columns:' + '\033[0m', df.columns, '\n')
# Print the value counts of the 'sentiment' column in the DataFrame 'df' with bold text formatting.
print('\033[1m' + 'df.sentiment.value_counts():' + '\033[0m')
print(df.sentiment.value_counts(), '\n')

# Plot a bar chart showing the distribution of sentiment values in the DataFrame 'df'.
# 'sns.axes_style("darkgrid")' sets the plotting style to darkgrid using Seaborn.
with sns.axes_style("darkgrid"):
    df['sentiment'].value_counts().plot.bar(color=['darkblue', 'r'], rot=0, fontsize='large')
    plt.show()

# Print the concise summary of the DataFrame 'df' with bold text formatting.
print('\033[1m' + 'df.info:' + '\033[0m')
df.info()


# In[9]:


df.sentiment = [1 if s == 'positive' else 0 for s in df.sentiment]
df


# # Text Cleaning
# 

# In[10]:


# Define a function to strip HTML tags from text
def strip_html(text):
    # Create a BeautifulSoup object to parse the HTML
    soup = BeautifulSoup(text, "html.parser")
    # Extract the text content from the HTML and return it
    return soup.get_text()

# Define a function to apply multiple text cleaning operations
def apply_map(text):
    # Check if the input is a string
    if isinstance(text, str):
        # Remove special characters enclosed in '<>' brackets
        text = re.sub(r'<@!#$%^&.*?>', '', text)
        # Remove any characters that are not letters, numbers, or whitespace
        text = re.sub(r'[^a-zA-Z0-9\s]', '', text)
        # Replace any non-word characters (excluding whitespace) with a space and remove leading/trailing whitespace
        text = re.sub(r'[^\w\s]', ' ', text).strip()
    return text

# Read the CSV file containing modified data into a DataFrame
df = pd.read_csv(r'C:\Users\mehbosha\Downloads\IMDB Dataset\IMDB Dataset.csv', encoding='latin1')
# Apply the apply_map function to clean text in all cells of the DataFrame
df = df.applymap(apply_map)
# Save the cleaned DataFrame to a new CSV file
df.to_csv('cleaned_file.csv', index=False)
# Print df
print(df)


# In[11]:


# Display the first 5 rows of the DataFrame.
df.head(10)


# In[12]:


# Display the last 5 rows of the DataFrame
df.tail(10)


# # Convert Text into Lower Case

# In[13]:


df = pd.read_csv(r'cleaned_file.csv', encoding='latin1')

# Convert all text in all columns to lowercase
df = df.applymap(lambda x: x.lower() if isinstance(x, str) else x)
df.to_csv('lowercased_file.csv', index=False)
# Print the DataFrame to verify the conversion
print(df)


# In[22]:


df.review[2]


# # Tokenization

# In[16]:


df = pd.read_csv(r'lowercased_file.csv', encoding='latin1')

# Tokenize text in all columns
for column in df.columns: 
    # Check if the column contains text data (assumed)
    if df[column].dtype == 'object':
        # Tokenize the text data using NLTK tokenizer
        df[column + '_Tokenized'] = df[column].apply(lambda x: word_tokenize(str(x)) if isinstance(x, str) else [])
# Print the DataFrame with tokenized text
df.to_csv('tokenized_file.csv', index=False)
print(df)


# # Stemming or Lemmatization

# In[20]:


# Load the CSV file
df = pd.read_csv(r'stopwords_file.csv', encoding='latin1', engine='python')

# Initialize Stemmer and Lemmatizer
stemmer = PorterStemmer()
lemmatizer = WordNetLemmatizer()

# Function to apply stemming
def apply_stemming(text):
    words = word_tokenize(str(text))
    stemmed_words = [stemmer.stem(word) for word in words]
    return ' '.join(stemmed_words)

# Function to apply lemmatization
def apply_lemmatization(text):
    words = word_tokenize(str(text))
    lemmatized_words = [lemmatizer.lemmatize(word) for word in words]
    return ' '.join(lemmatized_words)

# Apply stemming to all columns
stemmed_df = df.applymap(apply_stemming)

# Apply lemmatization to all columns
lemmatized_df = df.applymap(apply_lemmatization)

# Save the results to new CSV files
stemmed_df.to_csv('stemmed_output.csv', index=False)
lemmatized_df.to_csv('lemmatized_output.csv', index=False)
df


# # Stopword Removal

# In[21]:


# Define your stop words list (optional)
# You can customize the stopwords list by adding or removing words
stop_words = set(stopwords.words('english'))

# Load the CSV file
df = pd.read_csv(r'tokenized_file.csv', encoding='latin1')

# Define a function to remove stopwords from text
def remove_stopwords(text):
  # Lowercase the text (optional)
  text = text.lower()
  # Split the text into words
  words = text.split()
  # Filter out stopwords
  filtered_words = [word for word in words if word not in stop_words]
  # Join the filtered words back into a string
  return " ".join(filtered_words)
# Apply stopword removal to each column
for col in df.columns:
  # Check if the column contains text data (avoid removing stopwords from numerical columns)
  if pd.api.types.is_string_dtype(df[col]):
    df[col] = df[col].apply(remove_stopwords)

# Print the DataFrame with stopwords removed
df.to_csv('stopwords_file.csv', index=False)
print(df)


# In[22]:


df.review[1]

