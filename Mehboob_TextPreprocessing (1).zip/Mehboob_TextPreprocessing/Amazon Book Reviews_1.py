#!/usr/bin/env python
# coding: utf-8

# In[6]:


import pandas as pd
import numpy as np
import re
import nltk
import seaborn as sns
from scipy import stats
import matplotlib.pyplot as plt
import random
import pprint
from nltk import word_tokenize
from nltk.corpus import stopwords
from nltk.stem.porter import PorterStemmer
from nltk.tokenize.toktok import ToktokTokenizer
import spacy
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer, WordNetLemmatizer


# # Data Loading

# In[7]:


# Read the CSV file located at the specified path.
# The 'pd.read_csv()' function is used to read CSV files into a DataFrame.
# The file path 'C:\Users\mehbosha\Downloads\Books_rating.csv\Books_rating.csv' specifies the location of the CSV file to be read.
# The 'r' prefix before the string indicates that it's a raw string, preventing the backslashes from being treated as escape characters.
# The 'encoding' parameter is set to 'latin1', which specifies the character encoding used in the CSV file.
# This parameter ensures that the text data in the file is properly decoded using the Latin-1 encoding.
# The resulting DataFrame is assigned to the variable 'df' for further processing.
df = pd.read_csv(r'C:\Users\mehbosha\Downloads\Books_rating.csv\Books_rating.csv', encoding='latin1')


# In[8]:


df


# In[4]:


# Description of the DataFrame
df.describe()


# In[5]:


# Information about the DataFrame
df.info()


# In[6]:


# Display the first 5 rows of the DataFrame.
# The 'df.head()' function is used to retrieve the first few rows of the DataFrame.
# By passing the argument '5' inside the parentheses, we specify that we want to retrieve the first 5 rows.
# This allows us to quickly inspect the structure and contents of the DataFrame.
# It's a common practice to use 'df.head()' to get a quick overview of the data before performing further analysis or manipulation.
df.head(5)


# In[7]:


# Display the last 5 rows of the DataFrame
df.tail(5)


# # Duplicates

# In[27]:


# Load the dataset into a DataFrame
df = pd.read_csv(r'C:\Users\mehbosha\Downloads\Books_rating.csv\Books_rating.csv', encoding='latin1')
# Identify duplicate entries based on all columns
duplicate_rows = df[df.duplicated()]
# Remove duplicate entries
cleaned_df = df.drop_duplicates()
# Identify duplicate entries based on all columns
duplicate_rows = df[df.duplicated()]
# Remove duplicate entries
cleaned_df = df.drop_duplicates()


# In[28]:


df


# # Removing Numerical Values

# In[3]:


# Read the CSV file into a DataFrame
df = pd.read_csv(r'C:\Users\mehbosha\Downloads\Books_rating.csv\Books_rating.csv', encoding='latin1')
# Define a function to replace numerical values with placeholders
def replace_numerics(text, placeholder='NUMERIC_VALUE'):
    return re.sub(r'\b\d+\b', placeholder, str(text))
# Apply the replace_numerics function to all cells in the DataFrame
df = df.applymap(replace_numerics)
# Save the modified DataFrame to a new CSV file
df.to_csv('modified_file.csv', index=False)
print(df)


# # Missing Data

# In[32]:


# Calculate the sum of null values in each column of the DataFrame.
# The 'df.isnull()' function returns a DataFrame of boolean values, where True indicates a null value and False indicates a non-null value.
# The 'sum()' function is then used to calculate the sum of True values (nulls) for each column.
# This provides a count of null values in each column of the DataFrame.
print(df.isnull().sum())
print('\n\033[1mInference:\033[0m The dataset doesn\'t have any null elements')


# # Text Cleaning

# In[4]:


# Define a function to strip HTML tags from text
def strip_html(text):
    # Create a BeautifulSoup object to parse the HTML
    soup = BeautifulSoup(text, "html.parser")
    # Extract the text content from the HTML and return it
    return soup.get_text()

# Define a function to apply multiple text cleaning operations
def apply_map(text):
    # Check if the input is a string
    if isinstance(text, str):
        # Remove special characters enclosed in '<>' brackets
        text = re.sub(r'<@!#$%^&.*?>', '', text)
        # Remove any characters that are not letters, numbers, or whitespace
        text = re.sub(r'[^a-zA-Z0-9\s]', '', text)
        # Replace any non-word characters (excluding whitespace) with a space and remove leading/trailing whitespace
        text = re.sub(r'[^\w\s]', ' ', text).strip()
    return text

# Read the CSV file containing modified data into a DataFrame
df = pd.read_csv(r'modified_file.csv', encoding='latin1')
# Apply the apply_map function to clean text in all cells of the DataFrame
df = df.applymap(apply_map)
# Save the cleaned DataFrame to a new CSV file
df.to_csv('amazon_cleaned_file.csv', index=False)
# Print df
print(df)


# # Lowercasing

# In[5]:


df = pd.read_csv(r'amazon_cleaned_file.csv', encoding='latin1')

# Convert all text in all columns to lowercase
df = df.applymap(lambda x: x.lower() if isinstance(x, str) else x)
df.to_csv('amazon_lowercased_file.csv', index=False)

# Print the DataFrame to verify the conversion
print(df)


# In[61]:


pip install spacy


# # Tokenization

# In[6]:


df = pd.read_csv(r'amazon_lowercased_file.csv', encoding='latin1')

# Tokenize text in all columns
for column in df.columns: 
    # Check if the column contains text data (assumed)
    if df[column].dtype == 'object':
        # Tokenize the text data using NLTK tokenizer
        df[column + '_Tokenized'] = df[column].apply(lambda x: word_tokenize(str(x)) if isinstance(x, str) else [])
# Print the DataFrame with tokenized text
df.to_csv('amazon_tokenized_file.csv', index=False)
print(df)


# # Stopword Removal

# In[15]:


# Download the stopwords list for English from NLTK.
# Stopwords are common words like "the", "is", "at", "which", etc., that often don't carry significant meaning in a sentence.
nltk.download('stopwords')

# Create a set of stopwords for English.
# A set is a data structure that stores unique elements, automatically eliminating duplicates.
stop_words = set(stopwords.words('english'))

# Load the CSV file
file_path = 'amazon_tokenized_file.csv'
chunksize = 10000

# Define a function to remove stopwords from text
def remove_stopwords(text):
    # Check if the value is NaN
    if pd.isna(text):
        return text
    # Lowercase the text (optional)
    text = text.lower()
    # Split the text into words
    words = text.split()
    # Filter out stopwords
    filtered_words = [word for word in words if word not in stop_words]
    # Join the filtered words back into a string
    return " ".join(filtered_words)

# Chunk processing
for i, chunk in enumerate(pd.read_csv(file_path, chunksize=chunksize)):
    print(f"Processing chunk {i + 1}")
    # Apply stopword removal to each column
    for col in chunk.columns:
        # Check if the column contains text data (avoid removing stopwords from numerical columns)
        if chunk[col].dtype == 'object':  # Assuming text data is stored as object data type
            chunk[col] = chunk[col].apply(remove_stopwords)

    # Save the processed chunk to a new CSV file
    chunk.to_csv(f'amazon_stopwords_file_chunk_{i + 1}.csv', index=False)


# In[16]:


print(chunk)


# In[9]:


nltk.download('punkt')


# In[10]:


nltk.download('wordnet')


# # Stemming or Lemmatization

# In[17]:


# Load the CSV file
df = pd.read_csv(f'amazon_stopwords_file_chunk_{i + 1}.csv', encoding='latin1', engine='python')

# Initialize Stemmer and Lemmatizer
stemmer = PorterStemmer()
lemmatizer = WordNetLemmatizer()

# Function to apply stemming
def apply_stemming(text):
    words = word_tokenize(str(text))
    stemmed_words = [stemmer.stem(word) for word in words]
    return ' '.join(stemmed_words)

# Function to apply lemmatization
def apply_lemmatization(text):
    words = word_tokenize(str(text))
    lemmatized_words = [lemmatizer.lemmatize(word) for word in words]
    return ' '.join(lemmatized_words)

# Apply stemming to all columns
stemmed_df = df.applymap(apply_stemming)

# Apply lemmatization to all columns
lemmatized_df = df.applymap(apply_lemmatization)

# Save the results to new CSV files
stemmed_df.to_csv('amazon_stemmed_output.csv', index=False)
lemmatized_df.to_csv('amazon_lemmatized_output.csv', index=False)

print(df)


# In[ ]:




